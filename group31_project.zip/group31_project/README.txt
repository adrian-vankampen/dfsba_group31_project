Please run the main report named `00.Project_report.Rmd`.

Please note that we sometimes encountered some problems when running this file: some graphs did not show up at all in some runs, while they worked perfectly in others.
If you encounter such problems, close all and run again. The problem may be caused by some version conflicts on Windows mainly from what we read. There does not seem to be any fix for now.

Thank you.

Adrian and Allan